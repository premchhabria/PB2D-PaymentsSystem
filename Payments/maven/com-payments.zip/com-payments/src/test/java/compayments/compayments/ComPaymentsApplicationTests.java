package compayments.compayments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComPaymentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
